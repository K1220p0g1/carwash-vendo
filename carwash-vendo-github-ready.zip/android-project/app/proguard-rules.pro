# Keep USB-Serial driver classes accessed via reflection by ProbeTable
-keep class com.hoho.android.usbserial.driver.** { *; }
