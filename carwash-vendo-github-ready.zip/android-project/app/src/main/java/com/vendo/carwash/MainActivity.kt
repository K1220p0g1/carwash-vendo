package com.vendo.carwash

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.vendo.carwash.hardware.UsbSerialManager
import com.vendo.carwash.ui.CarwashVendoRoot
import com.vendo.carwash.viewmodel.VendoViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: VendoViewModel by viewModels()

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                UsbSerialManager.ACTION_USB_PERMISSION -> {
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    if (granted) {
                        viewModel.usbSerialManager.probeAndConnect()
                    }
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    viewModel.usbSerialManager.probeAndConnect()
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    viewModel.usbSerialManager.disconnect(notify = true, error = "USB cable detached")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep dedicated kiosk tablet display awake continuously
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableImmersiveKioskMode()

        registerUsbReceiver()
        viewModel.usbSerialManager.probeAndConnect()

        setContent {
            val uiState by viewModel.uiState.collectAsState()
            CarwashVendoRoot(
                state = uiState,
                onSelectMode = viewModel::selectWashMode,
                onOpenAdmin = viewModel::openAdminPinPrompt,
                onSubmitPin = viewModel::submitAdminPin,
                onExitAdmin = viewModel::exitAdmin,
                onUpdatePricing = viewModel::updatePricing,
                onToggleTestRelay = viewModel::toggleTestRelay,
                onResetEarnings = viewModel::resetEarnings,
                onReconnectUsb = { viewModel.usbSerialManager.probeAndConnect() }
            )
        }
    }

    private fun registerUsbReceiver() {
        val filter = IntentFilter().apply {
            addAction(UsbSerialManager.ACTION_USB_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(usbReceiver, filter)
        }
    }

    private fun enableImmersiveKioskMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(usbReceiver)
    }
}
