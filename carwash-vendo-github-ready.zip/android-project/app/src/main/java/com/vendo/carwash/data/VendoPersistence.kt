package com.vendo.carwash.data

import android.content.Context
import android.content.SharedPreferences
import com.vendo.carwash.model.CoinStats
import com.vendo.carwash.model.PricingConfig
import com.vendo.carwash.model.WashMode

/**
 * Non-volatile persistence layer designed for sudden power-loss resilience.
 *
 * Embedded Engineering Note:
 * Dedicated Android kiosk tablets often run without a healthy battery (powered
 * directly from a 12V->5V buck converter inside the vendo cabinet). If mains AC
 * drops mid-wash, async DataStore writes may still be buffered in memory.
 * Using SharedPreferences with synchronous `commit()` on critical credit
 * transitions ensures coin inserts and active balance checkpoints are flushed
 * to flash storage immediately.
 */
class VendoPersistence(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    data class RecoverySnapshot(
        val remainingCreditPhp: Double,
        val lastServiceMode: WashMode,
        val wasActive: Boolean
    )

    fun saveCreditCheckpoint(remainingCreditPhp: Double, lastServiceMode: WashMode, isActive: Boolean) {
        prefs.edit()
            .putLong(KEY_REMAINING_CREDIT_BITS, java.lang.Double.doubleToRawLongBits(remainingCreditPhp))
            .putString(KEY_LAST_SERVICE_MODE, lastServiceMode.name)
            .putBoolean(KEY_WAS_ACTIVE, isActive)
            .commit() // Synchronous flush to protect customer credit during power outage
    }

    fun clearCreditCheckpoint() {
        prefs.edit()
            .putLong(KEY_REMAINING_CREDIT_BITS, java.lang.Double.doubleToRawLongBits(0.0))
            .putBoolean(KEY_WAS_ACTIVE, false)
            .commit()
    }

    fun loadRecoverySnapshot(): RecoverySnapshot {
        val bits = prefs.getLong(KEY_REMAINING_CREDIT_BITS, java.lang.Double.doubleToRawLongBits(0.0))
        val credit = java.lang.Double.longBitsToDouble(bits).coerceAtLeast(0.0)
        val modeName = prefs.getString(KEY_LAST_SERVICE_MODE, WashMode.WATER.name) ?: WashMode.WATER.name
        val mode = runCatching { WashMode.valueOf(modeName) }.getOrDefault(WashMode.WATER)
        val wasActive = prefs.getBoolean(KEY_WAS_ACTIVE, false)
        return RecoverySnapshot(
            remainingCreditPhp = credit,
            lastServiceMode = if (mode == WashMode.PAUSED) WashMode.WATER else mode,
            wasActive = wasActive
        )
    }

    fun loadPricingConfig(): PricingConfig {
        return PricingConfig(
            waterSecondsPer5Php = prefs.getInt(KEY_WATER_SECS, 120),
            soapSecondsPer5Php = prefs.getInt(KEY_SOAP_SECS, 60),
            blowerSecondsPer5Php = prefs.getInt(KEY_BLOWER_SECS, 120)
        )
    }

    fun savePricingConfig(config: PricingConfig) {
        prefs.edit()
            .putInt(KEY_WATER_SECS, config.waterSecondsPer5Php)
            .putInt(KEY_SOAP_SECS, config.soapSecondsPer5Php)
            .putInt(KEY_BLOWER_SECS, config.blowerSecondsPer5Php)
            .apply()
    }

    fun recordCoinInsert(amountPhp: Int): CoinStats {
        val current = loadCoinStats()
        val updated = when (amountPhp) {
            1 -> current.copy(totalEarningsPhp = current.totalEarningsPhp + 1, count1Php = current.count1Php + 1)
            5 -> current.copy(totalEarningsPhp = current.totalEarningsPhp + 5, count5Php = current.count5Php + 1)
            10 -> current.copy(totalEarningsPhp = current.totalEarningsPhp + 10, count10Php = current.count10Php + 1)
            20 -> current.copy(totalEarningsPhp = current.totalEarningsPhp + 20, count20Php = current.count20Php + 1)
            else -> current.copy(totalEarningsPhp = current.totalEarningsPhp + amountPhp)
        }
        saveCoinStats(updated)
        return updated
    }

    fun loadCoinStats(): CoinStats {
        return CoinStats(
            totalEarningsPhp = prefs.getInt(KEY_TOTAL_EARNINGS, 0),
            count1Php = prefs.getInt(KEY_COIN_1, 0),
            count5Php = prefs.getInt(KEY_COIN_5, 0),
            count10Php = prefs.getInt(KEY_COIN_10, 0),
            count20Php = prefs.getInt(KEY_COIN_20, 0)
        )
    }

    fun resetCoinStats(): CoinStats {
        val empty = CoinStats()
        saveCoinStats(empty)
        return empty
    }

    fun loadAdminPin(): String = prefs.getString(KEY_ADMIN_PIN, "1234") ?: "1234"

    fun saveAdminPin(newPin: String) {
        prefs.edit().putString(KEY_ADMIN_PIN, newPin).apply()
    }

    private fun saveCoinStats(stats: CoinStats) {
        prefs.edit()
            .putInt(KEY_TOTAL_EARNINGS, stats.totalEarningsPhp)
            .putInt(KEY_COIN_1, stats.count1Php)
            .putInt(KEY_COIN_5, stats.count5Php)
            .putInt(KEY_COIN_10, stats.count10Php)
            .putInt(KEY_COIN_20, stats.count20Php)
            .commit()
    }

    companion object {
        private const val PREFS_NAME = "carwash_vendo_prefs"
        private const val KEY_REMAINING_CREDIT_BITS = "remaining_credit_bits"
        private const val KEY_LAST_SERVICE_MODE = "last_service_mode"
        private const val KEY_WAS_ACTIVE = "was_active"
        private const val KEY_WATER_SECS = "water_secs_per_5php"
        private const val KEY_SOAP_SECS = "soap_secs_per_5php"
        private const val KEY_BLOWER_SECS = "blower_secs_per_5php"
        private const val KEY_TOTAL_EARNINGS = "total_earnings_php"
        private const val KEY_COIN_1 = "coin_1_count"
        private const val KEY_COIN_5 = "coin_5_count"
        private const val KEY_COIN_10 = "coin_10_count"
        private const val KEY_COIN_20 = "coin_20_count"
        private const val KEY_ADMIN_PIN = "admin_pin"
    }
}
