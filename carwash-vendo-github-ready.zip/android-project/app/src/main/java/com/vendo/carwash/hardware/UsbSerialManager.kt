package com.vendo.carwash.hardware

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import com.hoho.android.usbserial.driver.CdcAcmSerialDriver
import com.hoho.android.usbserial.driver.Ch34xSerialDriver
import com.hoho.android.usbserial.driver.Cp21xxSerialDriver
import com.hoho.android.usbserial.driver.FtdiSerialDriver
import com.hoho.android.usbserial.driver.ProbeTable
import com.hoho.android.usbserial.driver.ProlificSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.util.SerialInputOutputManager
import com.vendo.carwash.model.WashMode
import java.io.IOException
import java.nio.charset.StandardCharsets

/**
 * Manages USB-to-Serial communication (CH340, PL2303, CP2102, FTDI, CDC/ACM)
 * between the Android kiosk tablet and the Arduino/ESP32 controller.
 *
 * Serial Protocol (115200 baud, 8N1, newline '\n' terminated):
 *   Inbound (ESP32 -> Android):
 *     COIN:1 | COIN:5 | COIN:10 | COIN:20
 *     BTN:WATER | BTN:SOAP | BTN:BLOWER | BTN:PAUSE
 *     PONG
 *     ERR:<reason>
 *   Outbound (Android -> ESP32):
 *     RELAY:WATER:ON\n
 *     RELAY:SOAP:ON\n
 *     RELAY:BLOWER:ON\n
 *     RELAY:ALL:OFF\n
 *     PING\n
 */
class UsbSerialManager(
    private val context: Context,
    private val onConnectionChanged: (connected: Boolean, deviceName: String, error: String?) -> Unit,
    private val onLineReceived: (line: String) -> Unit,
    private val onTxLine: (line: String) -> Unit
) : SerialInputOutputManager.Listener {

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private var serialPort: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null
    private val lineBuffer = StringBuilder()

    private val prober: UsbSerialProber by lazy {
        val customTable = ProbeTable().apply {
            // Standard + common clone CH340/CH341 IDs
            addProduct(0x1A86, 0x7523, Ch34xSerialDriver::class.java)
            addProduct(0x1A86, 0x5523, Ch34xSerialDriver::class.java)
            // Prolific PL2303
            addProduct(0x067B, 0x2303, ProlificSerialDriver::class.java)
            // Silicon Labs CP210x
            addProduct(0x10C4, 0xEA60, Cp21xxSerialDriver::class.java)
            // FTDI FT232
            addProduct(0x0403, 0x6001, FtdiSerialDriver::class.java)
            // Espressif ESP32-S2/S3/C3 Native USB CDC
            addProduct(0x303A, 0x1001, CdcAcmSerialDriver::class.java)
        }
        val merged = UsbSerialProber.getDefaultProber()
        // Prefer default prober, fall back to custom table
        object : UsbSerialProber(customTable) {
            override fun findAllDrivers(usbManager: UsbManager): MutableList<UsbSerialDriver> {
                val defaults = merged.findAllDrivers(usbManager)
                if (defaults.isNotEmpty()) return defaults
                return super.findAllDrivers(usbManager)
            }
        }
    }

    fun probeAndConnect() {
        val availableDrivers = prober.findAllDrivers(usbManager)
        if (availableDrivers.isEmpty()) {
            onConnectionChanged(false, "No USB Serial Device", null)
            return
        }

        val driver = availableDrivers.first()
        val device = driver.device

        if (!usbManager.hasPermission(device)) {
            requestPermission(device)
            return
        }

        openDriver(driver)
    }

    private fun requestPermission(device: UsbDevice) {
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_MUTABLE
        } else {
            0
        }
        val intent = Intent(ACTION_USB_PERMISSION).apply {
            setPackage(context.packageName)
        }
        val pendingIntent = PendingIntent.getBroadcast(context, 0, intent, flags)
        usbManager.requestPermission(device, pendingIntent)
    }

    private fun openDriver(driver: UsbSerialDriver) {
        disconnect(notify = false)
        val device = driver.device
        val connection = usbManager.openDevice(device)
        if (connection == null) {
            onConnectionChanged(false, device.productName ?: "USB Serial", "Failed to open USB device connection")
            return
        }

        try {
            val port = driver.ports.firstOrNull() ?: throw IOException("No serial ports on device")
            port.open(connection)
            port.setParameters(BAUD_RATE, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            port.dtr = true
            port.rts = true

            serialPort = port
            ioManager = SerialInputOutputManager(port, this).also {
                it.readTimeout = 200
                it.writeTimeout = 200
                it.start()
            }

            val label = device.productName?.takeIf { it.isNotBlank() }
                ?: "USB Serial (${String.format("0x%04X", device.vendorId)})"
            onConnectionChanged(true, label, null)

            // Safety guarantee: force all relays OFF immediately upon link establishment
            sendAllRelaysOff()
        } catch (e: Exception) {
            disconnect(notify = false)
            onConnectionChanged(false, device.productName ?: "USB Serial", e.message ?: "Serial open failed")
        }
    }

    fun sendModeCommand(mode: WashMode) {
        val cmd = when (mode) {
            WashMode.WATER -> "RELAY:WATER:ON"
            WashMode.SOAP -> "RELAY:SOAP:ON"
            WashMode.BLOWER -> "RELAY:BLOWER:ON"
            WashMode.PAUSED -> "RELAY:ALL:OFF"
        }
        sendLine(cmd)
    }

    fun sendAdminRelayTest(water: Boolean, soap: Boolean, blower: Boolean) {
        sendLine("TEST:${if (water) 1 else 0}:${if (soap) 1 else 0}:${if (blower) 1 else 0}")
    }

    fun sendAllRelaysOff() {
        sendLine("RELAY:ALL:OFF")
    }

    fun sendPing() {
        sendLine("PING")
    }

    @Synchronized
    fun sendLine(command: String) {
        val port = serialPort ?: return
        val payload = "$command\n".toByteArray(StandardCharsets.UTF_8)
        try {
            port.write(payload, WRITE_TIMEOUT_MS)
            onTxLine(command)
        } catch (e: IOException) {
            disconnect(notify = true, error = "Write error: ${e.message}")
        }
    }

    fun disconnect(notify: Boolean = true, error: String? = null) {
        try {
            ioManager?.listener = null
            ioManager?.stop()
        } catch (_: Exception) {
        } finally {
            ioManager = null
        }

        try {
            serialPort?.close()
        } catch (_: Exception) {
        } finally {
            serialPort = null
        }

        synchronized(lineBuffer) {
            lineBuffer.clear()
        }

        if (notify) {
            onConnectionChanged(false, "Disconnected", error)
        }
    }

    override fun onNewData(data: ByteArray) {
        val chunk = String(data, StandardCharsets.UTF_8)
        val completedLines = mutableListOf<String>()

        synchronized(lineBuffer) {
            lineBuffer.append(chunk)
            var newlineIdx = lineBuffer.indexOf("\n")
            while (newlineIdx >= 0) {
                val line = lineBuffer.substring(0, newlineIdx).trim()
                lineBuffer.delete(0, newlineIdx + 1)
                if (line.isNotEmpty()) {
                    completedLines.add(line)
                }
                newlineIdx = lineBuffer.indexOf("\n")
            }
        }

        completedLines.forEach { onLineReceived(it) }
    }

    override fun onRunError(e: Exception) {
        disconnect(notify = true, error = e.message ?: "USB serial link lost")
    }

    companion object {
        const val ACTION_USB_PERMISSION = "com.vendo.carwash.USB_PERMISSION"
        private const val BAUD_RATE = 115200
        private const val WRITE_TIMEOUT_MS = 300
    }
}
