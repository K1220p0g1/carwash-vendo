package com.vendo.carwash.model

enum class WashMode(
    val displayName: String,
    val serialTag: String
) {
    WATER("Water Rinse", "WATER"),
    SOAP("Foam Soap", "SOAP"),
    BLOWER("Air Blower", "BLOWER"),
    PAUSED("Paused", "PAUSED")
}

enum class AppScreen {
    IDLE,
    ACTIVE,
    ADMIN_PIN,
    ADMIN_DASHBOARD
}

data class PricingConfig(
    val waterSecondsPer5Php: Int = 120,  // Default: 5 PHP = 2 mins Water
    val soapSecondsPer5Php: Int = 60,    // Default: 5 PHP = 1 min Soap
    val blowerSecondsPer5Php: Int = 120  // Default: 5 PHP = 2 mins Blower
) {
    fun secondsPer5PhpFor(mode: WashMode): Int = when (mode) {
        WashMode.WATER -> waterSecondsPer5Php
        WashMode.SOAP -> soapSecondsPer5Php
        WashMode.BLOWER -> blowerSecondsPer5Php
        WashMode.PAUSED -> 0
    }

    /**
     * Returns PHP consumed per second while running [mode].
     * Example: 5 PHP = 120s Water -> 5.0 / 120.0 = 0.041667 PHP/sec.
     */
    fun phpPerSecond(mode: WashMode): Double {
        val secs = secondsPer5PhpFor(mode)
        return if (secs > 0) 5.0 / secs.toDouble() else 0.0
    }
}

data class RelayState(
    val water: Boolean = false,
    val soap: Boolean = false,
    val blower: Boolean = false
)

data class HardwareStatus(
    val isUsbConnected: Boolean = false,
    val deviceName: String = "No USB Serial Device",
    val lastHeartbeatAckMs: Long = 0L,
    val lastError: String? = null
)

data class CoinStats(
    val totalEarningsPhp: Int = 0,
    val count1Php: Int = 0,
    val count5Php: Int = 0,
    val count10Php: Int = 0,
    val count20Php: Int = 0
)

data class VendoUiState(
    val screen: AppScreen = AppScreen.IDLE,
    val activeMode: WashMode = WashMode.PAUSED,
    val lastSelectedService: WashMode = WashMode.WATER,
    val remainingCreditPhp: Double = 0.0,
    val displayedSecondsRemaining: Int = 0,
    val isRecoveredSession: Boolean = false,
    val pricing: PricingConfig = PricingConfig(),
    val hardware: HardwareStatus = HardwareStatus(),
    val relays: RelayState = RelayState(),
    val coinStats: CoinStats = CoinStats(),
    val serialLogs: List<String> = emptyList(),
    val adminPin: String = "1234"
)
