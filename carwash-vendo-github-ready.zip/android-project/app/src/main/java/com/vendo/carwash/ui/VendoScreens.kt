package com.vendo.carwash.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vendo.carwash.model.AppScreen
import com.vendo.carwash.model.PricingConfig
import com.vendo.carwash.model.VendoUiState
import com.vendo.carwash.model.WashMode

private val KioskBg = Color(0xFF0B1120)
private val KioskSurface = Color(0xFF131C31)
private val KioskBorder = Color(0xFF24324E)
private val WaterBlue = Color(0xFF0EA5E9)
private val SoapAmber = Color(0xFFF59E0B)
private val BlowerEmerald = Color(0xFF10B981)
private val DangerRed = Color(0xFFEF4444)

@Composable
fun CarwashVendoRoot(
    state: VendoUiState,
    onSelectMode: (WashMode) -> Unit,
    onOpenAdmin: () -> Unit,
    onSubmitPin: (String) -> Boolean,
    onExitAdmin: () -> Unit,
    onUpdatePricing: (PricingConfig) -> Unit,
    onToggleTestRelay: (WashMode) -> Unit,
    onResetEarnings: () -> Unit,
    onReconnectUsb: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = KioskBg,
        contentColor = Color.White
    ) {
        when (state.screen) {
            AppScreen.IDLE -> IdleScreen(
                state = state,
                onOpenAdmin = onOpenAdmin,
                onReconnectUsb = onReconnectUsb
            )
            AppScreen.ACTIVE -> ActiveSessionScreen(
                state = state,
                onSelectMode = onSelectMode,
                onOpenAdmin = onOpenAdmin
            )
            AppScreen.ADMIN_PIN -> AdminPinScreen(
                onSubmitPin = onSubmitPin,
                onCancel = onExitAdmin
            )
            AppScreen.ADMIN_DASHBOARD -> AdminDashboardScreen(
                state = state,
                onUpdatePricing = onUpdatePricing,
                onToggleTestRelay = onToggleTestRelay,
                onResetEarnings = onResetEarnings,
                onReconnectUsb = onReconnectUsb,
                onExit = onExitAdmin
            )
        }
    }
}

@Composable
private fun IdleScreen(
    state: VendoUiState,
    onOpenAdmin: () -> Unit,
    onReconnectUsb: () -> Unit
) {
    var secretTapCount by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Header with hidden 5-tap admin access on brand title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    secretTapCount++
                    if (secretTapCount >= 5) {
                        secretTapCount = 0
                        onOpenAdmin()
                    }
                }
            ) {
                Text(
                    text = "SELF-SERVICE CARWASH VENDO",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp,
                    color = Color.White
                )
                Text(
                    text = "Tap title 5× for Technician Settings",
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!state.hardware.isUsbConnected) {
                    OutlinedButton(
                        onClick = onReconnectUsb,
                        border = BorderStroke(1.dp, DangerRed),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed)
                    ) {
                        Icon(Icons.Rounded.UsbOff, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Hardware Offline — Retry")
                    }
                } else {
                    Text(
                        text = "Controller Ready (${state.hardware.deviceName})",
                        fontSize = 14.sp,
                        color = BlowerEmerald,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Center Insert Coin Hero Prompt
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(vertical = 24.dp)
                .background(KioskSurface, RoundedCornerShape(24.dp))
                .border(1.dp, KioskBorder, RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.MonetizationOn,
                    contentDescription = "Insert Coin",
                    tint = SoapAmber,
                    modifier = Modifier.size(72.dp)
                )
                Text(
                    text = "INSERT COIN TO START",
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
                Text(
                    text = "Accepts ₱1, ₱5, ₱10, and ₱20 coins — Switch modes anytime during wash",
                    fontSize = 18.sp,
                    color = Color(0xFFCBD5E1)
                )
            }
        }

        // Pricing Tiers Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            PricingTierCard(
                modifier = Modifier.weight(1f),
                title = "HIGH-PRESSURE WATER",
                priceRate = "₱5 = ${formatDuration(state.pricing.waterSecondsPer5Php)}",
                accent = WaterBlue,
                icon = Icons.Rounded.WaterDrop
            )
            PricingTierCard(
                modifier = Modifier.weight(1f),
                title = "FOAM SOAP",
                priceRate = "₱5 = ${formatDuration(state.pricing.soapSecondsPer5Php)}",
                accent = SoapAmber,
                icon = Icons.Rounded.BubbleChart
            )
            PricingTierCard(
                modifier = Modifier.weight(1f),
                title = "AIR BLOWER",
                priceRate = "₱5 = ${formatDuration(state.pricing.blowerSecondsPer5Php)}",
                accent = BlowerEmerald,
                icon = Icons.Rounded.Air
            )
        }
    }
}

@Composable
private fun PricingTierCard(
    modifier: Modifier,
    title: String,
    priceRate: String,
    accent: Color,
    icon: ImageVector
) {
    Column(
        modifier = modifier
            .background(KioskSurface, RoundedCornerShape(18.dp))
            .border(1.dp, KioskBorder, RoundedCornerShape(18.dp))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(26.dp))
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE2E8F0))
        }
        Text(
            text = priceRate,
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace,
            color = accent
        )
    }
}

@Composable
private fun ActiveSessionScreen(
    state: VendoUiState,
    onSelectMode: (WashMode) -> Unit,
    onOpenAdmin: () -> Unit
) {
    var secretTapCount by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Status Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ACTIVE WASH SESSION",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF94A3B8),
                modifier = Modifier.clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    secretTapCount++
                    if (secretTapCount >= 5) {
                        secretTapCount = 0
                        onOpenAdmin()
                    }
                }
            )

            Text(
                text = "BALANCE: ₱${"%.2f".format(state.remainingCreditPhp)}",
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                color = SoapAmber
            )
        }

        if (state.isRecoveredSession) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF422006), RoundedCornerShape(12.dp))
                    .border(1.dp, SoapAmber, RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(
                    text = "Power restored: Unspent credit recovered safely. Select Water, Soap, or Blower to resume.",
                    color = Color(0xFFFEF3C7),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Giant Countdown Display
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(vertical = 16.dp)
                .background(KioskSurface, RoundedCornerShape(24.dp))
                .border(1.dp, KioskBorder, RoundedCornerShape(24.dp)),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            val activeAccent = when (state.activeMode) {
                WashMode.WATER -> WaterBlue
                WashMode.SOAP -> SoapAmber
                WashMode.BLOWER -> BlowerEmerald
                WashMode.PAUSED -> Color(0xFF94A3B8)
            }
            Text(
                text = if (state.activeMode == WashMode.PAUSED) {
                    "PAUSED — SELECT A MODE BELOW"
                } else {
                    "RUNNING: ${state.activeMode.displayName.uppercase()}"
                },
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = activeAccent
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = formatDuration(state.displayedSecondsRemaining),
                fontSize = 96.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = Color.White
            )
            Text(
                text = "Estimated time at ${state.lastSelectedService.displayName} rate (₱5 = ${
                    formatDuration(state.pricing.secondsPer5PhpFor(state.lastSelectedService))
                })",
                fontSize = 15.sp,
                color = Color(0xFF94A3B8)
            )
        }

        // Large Kiosk Mode Selector Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(112.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ModeActionButton(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                label = "WATER",
                subLabel = "₱5 = ${formatDuration(state.pricing.waterSecondsPer5Php)}",
                icon = Icons.Rounded.WaterDrop,
                isSelected = state.activeMode == WashMode.WATER,
                accent = WaterBlue,
                onClick = { onSelectMode(WashMode.WATER) }
            )
            ModeActionButton(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                label = "SOAP",
                subLabel = "₱5 = ${formatDuration(state.pricing.soapSecondsPer5Php)}",
                icon = Icons.Rounded.BubbleChart,
                isSelected = state.activeMode == WashMode.SOAP,
                accent = SoapAmber,
                onClick = { onSelectMode(WashMode.SOAP) }
            )
            ModeActionButton(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                label = "BLOWER",
                subLabel = "₱5 = ${formatDuration(state.pricing.blowerSecondsPer5Php)}",
                icon = Icons.Rounded.Air,
                isSelected = state.activeMode == WashMode.BLOWER,
                accent = BlowerEmerald,
                onClick = { onSelectMode(WashMode.BLOWER) }
            )
            ModeActionButton(
                modifier = Modifier.weight(0.8f).fillMaxHeight(),
                label = "PAUSE",
                subLabel = "Hold Credit",
                icon = Icons.Rounded.PauseCircle,
                isSelected = state.activeMode == WashMode.PAUSED,
                accent = Color(0xFF94A3B8),
                onClick = { onSelectMode(WashMode.PAUSED) }
            )
        }
    }
}

@Composable
private fun ModeActionButton(
    modifier: Modifier,
    label: String,
    subLabel: String,
    icon: ImageVector,
    isSelected: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) accent else KioskSurface,
            contentColor = if (isSelected) Color(0xFF090D16) else Color.White
        ),
        border = BorderStroke(2.dp, if (isSelected) accent else KioskBorder)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = label, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(4.dp))
            Text(label, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Text(subLabel, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun AdminPinScreen(
    onSubmitPin: (String) -> Boolean,
    onCancel: () -> Unit
) {
    var pinInput by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("TECHNICIAN ADMIN ACCESS", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Enter 4-digit PIN (Default: 1234)", color = Color(0xFF94A3B8))
        Spacer(Modifier.height(20.dp))

        Text(
            text = pinInput.padEnd(4, '•').mapIndexed { idx, c -> if (idx < pinInput.length) "●" else "○" }.joinToString("  "),
            fontSize = 36.sp,
            fontFamily = FontFamily.Monospace,
            color = WaterBlue
        )

        if (errorMsg != null) {
            Spacer(Modifier.height(8.dp))
            Text(errorMsg!!, color = DangerRed, fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.height(20.dp))
        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("CLR", "0", "OK"))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { key ->
                        Button(
                            onClick = {
                                errorMsg = null
                                when (key) {
                                    "CLR" -> pinInput = ""
                                    "OK" -> {
                                        if (!onSubmitPin(pinInput)) {
                                            errorMsg = "Incorrect PIN"
                                            pinInput = ""
                                        }
                                    }
                                    else -> if (pinInput.length < 4) pinInput += key
                                }
                            },
                            modifier = Modifier.size(width = 96.dp, height = 60.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (key == "OK") WaterBlue else KioskSurface
                            )
                        ) {
                            Text(key, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        TextButton(onClick = onCancel) {
            Text("Cancel & Return to Kiosk", color = Color(0xFF94A3B8))
        }
    }
}

@Composable
private fun AdminDashboardScreen(
    state: VendoUiState,
    onUpdatePricing: (PricingConfig) -> Unit,
    onToggleTestRelay: (WashMode) -> Unit,
    onResetEarnings: () -> Unit,
    onReconnectUsb: () -> Unit,
    onExit: () -> Unit
) {
    var waterSecs by remember(state.pricing) { mutableIntStateOf(state.pricing.waterSecondsPer5Php) }
    var soapSecs by remember(state.pricing) { mutableIntStateOf(state.pricing.soapSecondsPer5Php) }
    var blowerSecs by remember(state.pricing) { mutableIntStateOf(state.pricing.blowerSecondsPer5Php) }

    Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ADMIN DASHBOARD & HARDWARE DIAGNOSTICS", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Button(onClick = onExit, colors = ButtonDefaults.buttonColors(containerColor = WaterBlue)) {
                Text("Save & Exit to Kiosk")
            }
        }

        Spacer(Modifier.height(16.dp))

        Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            // Left Column: Pricing Config + Earnings
            Column(
                modifier = Modifier.weight(1f).background(KioskSurface, RoundedCornerShape(16.dp)).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("PRICING RATES (SECONDS PER ₱5 COIN)", fontWeight = FontWeight.Bold, color = WaterBlue)
                RateStepperRow("Water Pump", waterSecs) { waterSecs = it }
                RateStepperRow("Foam Soap", soapSecs) { soapSecs = it }
                RateStepperRow("Air Blower", blowerSecs) { blowerSecs = it }

                Button(
                    onClick = { onUpdatePricing(PricingConfig(waterSecs, soapSecs, blowerSecs)) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Apply Rate Changes")
                }

                HorizontalDivider(color = KioskBorder)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("TOTAL EARNINGS", fontSize = 12.sp, color = Color(0xFF94A3B8))
                        Text(
                            "₱${state.coinStats.totalEarningsPhp}",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = BlowerEmerald
                        )
                        Text(
                            "₱1×${state.coinStats.count1Php} · ₱5×${state.coinStats.count5Php} · ₱10×${state.coinStats.count10Php} · ₱20×${state.coinStats.count20Php}",
                            fontSize = 12.sp,
                            color = Color(0xFFCBD5E1)
                        )
                    }
                    OutlinedButton(onClick = onResetEarnings) {
                        Text("Reset Counter", color = DangerRed)
                    }
                }
            }

            // Right Column: Hardware Relay Test + Serial Monitor
            Column(
                modifier = Modifier.weight(1f).background(KioskSurface, RoundedCornerShape(16.dp)).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("MANUAL RELAY HARDWARE TEST", fontWeight = FontWeight.Bold, color = SoapAmber)
                    TextButton(onClick = onReconnectUsb) { Text("Probe USB") }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    RelayTestButton("Water Relay", state.relays.water, Modifier.weight(1f)) {
                        onToggleTestRelay(WashMode.WATER)
                    }
                    RelayTestButton("Soap Relay", state.relays.soap, Modifier.weight(1f)) {
                        onToggleTestRelay(WashMode.SOAP)
                    }
                    RelayTestButton("Blower Relay", state.relays.blower, Modifier.weight(1f)) {
                        onToggleTestRelay(WashMode.BLOWER)
                    }
                }

                Text("SERIAL MONITOR (${state.hardware.deviceName})", fontSize = 12.sp, color = Color(0xFF94A3B8))
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(KioskBg, RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    items(state.serialLogs) { line ->
                        Text(line, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color(0xFFCBD5E1))
                    }
                }
            }
        }
    }
}

@Composable
private fun RateStepperRow(label: String, seconds: Int, onChange: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { onChange((seconds - 15).coerceAtLeast(15)) }) { Text("-15s") }
            Text(
                formatDuration(seconds),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.width(64.dp),
                textAlign = TextAlign.Center
            )
            OutlinedButton(onClick = { onChange((seconds + 15).coerceAtMost(600)) }) { Text("+15s") }
        }
    }
}

@Composable
private fun RelayTestButton(label: String, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(54.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (active) BlowerEmerald else KioskBg,
            contentColor = if (active) Color.Black else Color.White
        ),
        border = BorderStroke(1.dp, if (active) BlowerEmerald else KioskBorder)
    ) {
        Text(if (active) "$label: ON" else "$label: OFF", fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

private fun formatDuration(totalSeconds: Int): String {
    val safe = totalSeconds.coerceAtLeast(0)
    val mins = safe / 60
    val secs = safe % 60
    return "%02d:%02d".format(mins, secs)
}
