package com.vendo.carwash.viewmodel

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vendo.carwash.data.VendoPersistence
import com.vendo.carwash.hardware.UsbSerialManager
import com.vendo.carwash.model.AppScreen
import com.vendo.carwash.model.PricingConfig
import com.vendo.carwash.model.RelayState
import com.vendo.carwash.model.VendoUiState
import com.vendo.carwash.model.WashMode
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.ceil

/**
 * Core state machine for the Carwash Vendo kiosk.
 *
 * Key Reliability Guarantees:
 * 1. Credit-Pool Accounting: Balance is tracked in PHP (Double) rather than fixed
 *    integer seconds. Switching between Water (e.g. 5 PHP = 120s) and Soap
 *    (5 PHP = 60s) immediately recalculates the displayed countdown without rounding
 *    drift or credit loss.
 * 2. Monotonic Clock Deltas: Uses SystemClock.elapsedRealtime() so coroutine
 *    scheduling jitter never drifts the countdown timer.
 * 3. Power-Interruption Recovery: Every coin pulse and mode change commits
 *    synchronously to non-volatile storage, and active washes checkpoint every 2s.
 *    If power cuts out and the tablet reboots, unspent credit is restored in PAUSED
 *    state with relays OFF so pumps do not engage unattended.
 */
class VendoViewModel(application: Application) : AndroidViewModel(application) {

    private val persistence = VendoPersistence(application.applicationContext)

    private val _uiState = MutableStateFlow(VendoUiState())
    val uiState: StateFlow<VendoUiState> = _uiState.asStateFlow()

    val usbSerialManager: UsbSerialManager by lazy {
        UsbSerialManager(
            context = application.applicationContext,
            onConnectionChanged = ::handleUsbConnectionChanged,
            onLineReceived = ::handleSerialLineReceived,
            onTxLine = { cmd -> appendLog("TX -> $cmd") }
        )
    }

    private var timerJob: Job? = null
    private var heartbeatJob: Job? = null
    private var lastCheckpointMs: Long = 0L

    init {
        restoreFromPersistence()
        startHeartbeatWatchdog()
    }

    private fun restoreFromPersistence() {
        val pricing = persistence.loadPricingConfig()
        val stats = persistence.loadCoinStats()
        val pin = persistence.loadAdminPin()
        val recovery = persistence.loadRecoverySnapshot()

        val hasRecoveredCredit = recovery.remainingCreditPhp > 0.01
        val initialScreen = if (hasRecoveredCredit) AppScreen.ACTIVE else AppScreen.IDLE
        val displayedSecs = if (hasRecoveredCredit) {
            computeSecondsForCredit(recovery.remainingCreditPhp, recovery.lastServiceMode, pricing)
        } else {
            0
        }

        _uiState.update {
            it.copy(
                screen = initialScreen,
                activeMode = WashMode.PAUSED, // Always boot with relays OFF for safety
                lastSelectedService = recovery.lastServiceMode,
                remainingCreditPhp = recovery.remainingCreditPhp,
                displayedSecondsRemaining = displayedSecs,
                isRecoveredSession = hasRecoveredCredit,
                pricing = pricing,
                coinStats = stats,
                adminPin = pin,
                relays = RelayState()
            )
        }

        if (hasRecoveredCredit) {
            appendLog("RECOVERY: Restored ₱${"%.2f".format(recovery.remainingCreditPhp)} in PAUSED state")
        }
    }

    private fun startHeartbeatWatchdog() {
        heartbeatJob?.cancel()
        heartbeatJob = viewModelScope.launch {
            while (isActive) {
                if (_uiState.value.hardware.isUsbConnected) {
                    usbSerialManager.sendPing()
                }
                delay(1000L)
            }
        }
    }

    private fun handleUsbConnectionChanged(connected: Boolean, deviceName: String, error: String?) {
        _uiState.update { state ->
            val shouldSafetyPause = !connected && state.activeMode != WashMode.PAUSED
            if (shouldSafetyPause) {
                timerJob?.cancel()
                persistence.saveCreditCheckpoint(state.remainingCreditPhp, state.lastSelectedService, false)
            }
            state.copy(
                activeMode = if (shouldSafetyPause) WashMode.PAUSED else state.activeMode,
                relays = if (!connected) RelayState() else state.relays,
                hardware = state.hardware.copy(
                    isUsbConnected = connected,
                    deviceName = deviceName,
                    lastError = error
                )
            )
        }
        appendLog(if (connected) "USB: Connected to $deviceName" else "USB: Disconnected (${error ?: "unplugged"})")
    }

    private fun handleSerialLineReceived(line: String) {
        appendLog("RX <- $line")
        when {
            line.startsWith("COIN:") -> {
                val amount = line.removePrefix("COIN:").trim().toIntOrNull()
                if (amount != null && amount > 0) {
                    onCoinInserted(amount)
                }
            }
            line.startsWith("BTN:") -> {
                val btn = line.removePrefix("BTN:").trim()
                when (btn) {
                    "WATER" -> selectWashMode(WashMode.WATER)
                    "SOAP" -> selectWashMode(WashMode.SOAP)
                    "BLOWER" -> selectWashMode(WashMode.BLOWER)
                    "PAUSE" -> selectWashMode(WashMode.PAUSED)
                }
            }
            line == "PONG" -> {
                _uiState.update {
                    it.copy(hardware = it.hardware.copy(lastHeartbeatAckMs = SystemClock.elapsedRealtime()))
                }
            }
            line.startsWith("ERR:") -> {
                _uiState.update {
                    it.copy(hardware = it.hardware.copy(lastError = line.removePrefix("ERR:").trim()))
                }
            }
        }
    }

    /**
     * Triggered when the coin acceptor sends a validated coin pulse train.
     */
    fun onCoinInserted(amountPhp: Int) {
        val updatedStats = persistence.recordCoinInsert(amountPhp)

        _uiState.update { state ->
            val newCredit = state.remainingCreditPhp + amountPhp.toDouble()
            val targetService = if (state.activeMode == WashMode.PAUSED) {
                state.lastSelectedService
            } else {
                state.activeMode
            }
            val nextScreen = if (state.screen == AppScreen.IDLE) AppScreen.ACTIVE else state.screen
            val seconds = computeSecondsForCredit(newCredit, targetService, state.pricing)

            persistence.saveCreditCheckpoint(
                remainingCreditPhp = newCredit,
                lastServiceMode = targetService,
                isActive = state.activeMode != WashMode.PAUSED
            )

            state.copy(
                screen = nextScreen,
                remainingCreditPhp = newCredit,
                displayedSecondsRemaining = seconds,
                coinStats = updatedStats,
                isRecoveredSession = false
            )
        }
        appendLog("COIN: +₱$amountPhp credited")
    }

    /**
     * Switches between WATER, SOAP, BLOWER, or PAUSED.
     * Changing modes immediately updates the Arduino/ESP32 relays and recalculates
     * remaining seconds according to the newly selected mode's PHP/min rate.
     */
    fun selectWashMode(mode: WashMode) {
        val current = _uiState.value
        if (current.remainingCreditPhp <= 0.0) return

        val nextService = if (mode == WashMode.PAUSED) current.lastSelectedService else mode
        val nextRelays = RelayState(
            water = mode == WashMode.WATER,
            soap = mode == WashMode.SOAP,
            blower = mode == WashMode.BLOWER
        )

        persistence.saveCreditCheckpoint(
            remainingCreditPhp = current.remainingCreditPhp,
            lastServiceMode = nextService,
            isActive = mode != WashMode.PAUSED
        )

        _uiState.update { state ->
            state.copy(
                activeMode = mode,
                lastSelectedService = nextService,
                displayedSecondsRemaining = computeSecondsForCredit(
                    state.remainingCreditPhp,
                    nextService,
                    state.pricing
                ),
                isRecoveredSession = false,
                relays = nextRelays
            )
        }

        usbSerialManager.sendModeCommand(mode)

        if (mode == WashMode.PAUSED) {
            timerJob?.cancel()
        } else {
            ensureTimerLoopRunning()
        }
    }

    private fun ensureTimerLoopRunning() {
        if (timerJob?.isActive == true) return

        timerJob = viewModelScope.launch {
            var lastTickMs = SystemClock.elapsedRealtime()
            lastCheckpointMs = lastTickMs

            while (isActive) {
                delay(200L)
                val nowMs = SystemClock.elapsedRealtime()
                val deltaSec = (nowMs - lastTickMs) / 1000.0
                lastTickMs = nowMs

                val state = _uiState.value
                if (state.activeMode == WashMode.PAUSED || state.screen != AppScreen.ACTIVE) {
                    break
                }

                val ratePhpPerSec = state.pricing.phpPerSecond(state.activeMode)
                val updatedCredit = (state.remainingCreditPhp - (ratePhpPerSec * deltaSec)).coerceAtLeast(0.0)

                if (updatedCredit <= 0.0001) {
                    finishSession()
                    break
                } else {
                    val displayedSecs = computeSecondsForCredit(updatedCredit, state.activeMode, state.pricing)
                    _uiState.update {
                        it.copy(
                            remainingCreditPhp = updatedCredit,
                            displayedSecondsRemaining = displayedSecs
                        )
                    }

                    // Persist active credit every 2 seconds to cap max loss during power cut
                    if (nowMs - lastCheckpointMs >= 2000L) {
                        lastCheckpointMs = nowMs
                        persistence.saveCreditCheckpoint(updatedCredit, state.lastSelectedService, true)
                    }
                }
            }
        }
    }

    private fun finishSession() {
        timerJob?.cancel()
        persistence.clearCreditCheckpoint()
        usbSerialManager.sendAllRelaysOff()

        _uiState.update {
            it.copy(
                screen = AppScreen.IDLE,
                activeMode = WashMode.PAUSED,
                remainingCreditPhp = 0.0,
                displayedSecondsRemaining = 0,
                relays = RelayState()
            )
        }
        appendLog("SESSION: Credit depleted, all relays OFF")
    }

    fun openAdminPinPrompt() {
        // Pause active wash safely if admin enters settings
        if (_uiState.value.activeMode != WashMode.PAUSED) {
            selectWashMode(WashMode.PAUSED)
        }
        _uiState.update { it.copy(screen = AppScreen.ADMIN_PIN) }
    }

    fun submitAdminPin(pinAttempt: String): Boolean {
        return if (pinAttempt == _uiState.value.adminPin) {
            _uiState.update { it.copy(screen = AppScreen.ADMIN_DASHBOARD) }
            true
        } else {
            false
        }
    }

    fun exitAdmin() {
        // Ensure test relays are shut off before returning to customer UI
        usbSerialManager.sendAllRelaysOff()
        _uiState.update { state ->
            val targetScreen = if (state.remainingCreditPhp > 0.01) AppScreen.ACTIVE else AppScreen.IDLE
            state.copy(
                screen = targetScreen,
                relays = RelayState()
            )
        }
    }

    fun updatePricing(newConfig: PricingConfig) {
        persistence.savePricingConfig(newConfig)
        _uiState.update { state ->
            state.copy(
                pricing = newConfig,
                displayedSecondsRemaining = computeSecondsForCredit(
                    state.remainingCreditPhp,
                    state.lastSelectedService,
                    newConfig
                )
            )
        }
        appendLog("ADMIN: Pricing updated (W:${newConfig.waterSecondsPer5Php}s S:${newConfig.soapSecondsPer5Php}s B:${newConfig.blowerSecondsPer5Php}s)")
    }

    fun toggleTestRelay(mode: WashMode) {
        if (_uiState.value.screen != AppScreen.ADMIN_DASHBOARD) return
        val current = _uiState.value.relays
        val next = when (mode) {
            WashMode.WATER -> current.copy(water = !current.water)
            WashMode.SOAP -> current.copy(soap = !current.soap)
            WashMode.BLOWER -> current.copy(blower = !current.blower)
            WashMode.PAUSED -> RelayState()
        }
        _uiState.update { it.copy(relays = next) }
        usbSerialManager.sendAdminRelayTest(next.water, next.soap, next.blower)
    }

    fun resetEarnings() {
        val cleared = persistence.resetCoinStats()
        _uiState.update { it.copy(coinStats = cleared) }
        appendLog("ADMIN: Earnings counter reset")
    }

    fun updateAdminPin(newPin: String) {
        if (newPin.length == 4 && newPin.all { it.isDigit() }) {
            persistence.saveAdminPin(newPin)
            _uiState.update { it.copy(adminPin = newPin) }
        }
    }

    private fun computeSecondsForCredit(
        creditPhp: Double,
        serviceMode: WashMode,
        pricing: PricingConfig
    ): Int {
        if (creditPhp <= 0.0) return 0
        val rate = pricing.phpPerSecond(serviceMode)
        if (rate <= 0.0) return 0
        return ceil(creditPhp / rate).toInt()
    }

    private fun appendLog(entry: String) {
        _uiState.update { state ->
            val updated = (listOf(entry) + state.serialLogs).take(40)
            state.copy(serialLogs = updated)
        }
    }

    override fun onCleared() {
        super.onCleared()
        usbSerialManager.sendAllRelaysOff()
        usbSerialManager.disconnect(notify = false)
    }
}
